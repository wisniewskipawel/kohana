<?php global $petsitter_data; 
$field_submit = $petsitter_data['petsitter__slider-resumes-field-submit']; ?>

<div class="form-group">
	<button type="submit" class="btn btn-primary btn-block"><?php echo $field_submit; ?></button>
</div>