<?php global $petsitter_data; 
$field_location = $petsitter_data['petsitter__slider-resumes-field-location']; ?>

<div class="form-group">
	<input type="text" id="search_location" class="form-control" name="search_location" placeholder="<?php echo $field_location;  ?>" />
</div>