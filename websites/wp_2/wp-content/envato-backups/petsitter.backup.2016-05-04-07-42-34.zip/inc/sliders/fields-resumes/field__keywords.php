<?php global $petsitter_data; 
$field_keywords = $petsitter_data['petsitter__slider-resumes-field-keywords']; ?>

<div class="form-group">
	<input type="text" id="search_keywords" class="form-control" name="search_keywords" placeholder="<?php echo $field_keywords;  ?>" />
</div>