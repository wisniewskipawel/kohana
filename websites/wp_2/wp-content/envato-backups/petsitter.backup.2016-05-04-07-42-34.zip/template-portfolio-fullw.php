<?php /* Template Name: Portfolio Full Width */ ?>
<?php get_header(); ?>

<?php get_template_part('loop-portfolio'); ?>

<?php get_footer(); ?>